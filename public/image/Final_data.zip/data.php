<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "res";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$roll_number = $_POST['roll_number']; // Retrieve roll number from the form

$sql = "SELECT name ,enroll ,course ,father_name ,mother_name ,grade ,result FROM res_tb WHERE roll = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$stmt->bind_result($name ,$enroll ,$course ,$father_name ,$mother_name ,$grade ,$result);
$stmt->fetch();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.2/html2canvas.min.js"></script>
<style>
    <style>
             body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        .student-info {
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Result</h1>
    <!-- <?php if ($name) : ?>
        <p>Name: <?php echo $name; ?></p>
        <p>Score: <?php echo $score; ?></p>
    <?php else : ?>
        <p>Result not found for roll number: <?php echo $roll_number; ?></p>
    <?php endif; ?> -->
    

    <?php if ($name) : ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-2">
                <img src="jnulg.jpg" class="img-fluid" alt="" height="100px" width="100px">
            </div>
            <div class="col-10">
                <span class="h4">ANURAG COMPUTER INSTITUTE OF IT & MANAGEMENT <span style="font-size:12px">
                    (Malhani Bazar (pnb bank first floor) Jaunpur</span></span>
            </div>
        </div>
        <div class="student-info">
            <div class="row">
                <div class="col-6">
                    <p><strong>RollNO:</strong> <?php echo $roll_number; ?></p>
                </div>
                <div class="col-6">
                    <p><strong>EnrollmentNo:</strong> <?php echo $enroll; ?></p>
                </div>
            </div>
            
            
            <p><strong>StudentName:</strong> <?php echo $name; ?></p>
            <p><strong>FatherName:</strong>  <?php echo $father_name; ?></p>
            <p><strong>MotherName:</strong> <?php echo $mother_name; ?></p>
            <p><strong>Course:</strong> <?php echo $course; ?></p>
            <div class="row">
                <div class="col-6">
                    <p><strong>Grade: </strong> <?php echo $grade; ?></p>
                </div>
                <div class="col-6">
                    <p><strong>Result:</strong> <?php echo $result; ?></p>
                </div>
            </div>
            <button id="printButton" >Download Result</button>
        </div>
        <?php else : ?>
        <p>Result not found for roll number: <?php echo $roll_number; ?></p>
        <?php endif; ?>
            
        <script>
        document.getElementById('printButton').addEventListener('click', function() {
            window.print();
        });
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
