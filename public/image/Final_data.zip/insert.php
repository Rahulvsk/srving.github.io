
<!DOCTYPE html>
<html>
<head>
    <title>Student Information Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

.container {
    background-color: #fff;
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

input {
    width: 95%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container mt-5" style="margin-top:50px">
        <h2>Student Information Form</h2>
        <form id="studentForm" method="post">
            <input type="text" name="rollno" placeholder="Roll Number" required>
            <input type="text" name="enrollno" placeholder="Enrollment Number" required>
            <input type="text" name="studentname" placeholder="Student Name" required>
            <input type="text" name="fathername" placeholder="Father's Name" required>
            <input type="text" name="mothername" placeholder="Mother's Name" required>
            <input type="text" name="course" placeholder="Course" required>
            <input type="text" name="grade" placeholder="Grade" required>
            <input type="text" name="result" placeholder="Result" required>
            <button type="submit" id="submit">Submit</button>
        </form>
    </div>
    <div class="message" id="message"></div>
    <script >
        document.addEventListener('DOMContentLoaded', function () {
    const studentForm = document.getElementById('studentForm');
    const message = document.getElementById('message');

    studentForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(studentForm);

        fetch('insert_data.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            message.innerText = data;
            studentForm.reset();
        })
        .catch(error => {
            message.innerText = 'An error occurred.';
        });
    });
});

    </script>
</body>
</html>
