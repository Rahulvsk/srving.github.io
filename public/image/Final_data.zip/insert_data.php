<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "res";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$rollno = $_POST['rollno'];
$enrollno = $_POST['enrollno'];
$studentname = $_POST['studentname'];
$fathername = $_POST['fathername'];
$mothername = $_POST['mothername'];
$course = $_POST['course'];
$grade = $_POST['grade'];
$result = $_POST['result'];

// SQL query to insert the data into the database
$sql = "INSERT INTO res_tb (roll, enroll, name, father_name, mother_name, course, grade, result)
VALUES ('$rollno', '$enrollno', '$studentname', '$fathername', '$mothername', '$course', '$grade', '$result')";

if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
